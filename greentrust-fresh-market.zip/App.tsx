
import React, { useState, useMemo, useEffect } from 'react';
import { MASTER_PRODUCTS } from './constants';
import { Category, Product, CartItem } from './types';
import { ProductCard } from './components/ProductCard';
import { Assistant } from './components/Assistant';

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [location, setLocation] = useState('Detecting location...');

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setLocation(`Ambattur, Chennai`); // Specific location from your screenshot!
      }, () => setLocation('Ambattur, Chennai'));
    } else {
      setLocation('Ambattur, Chennai');
    }
  }, []);

  const filteredProducts = useMemo(() => {
    return MASTER_PRODUCTS.filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category.includes(activeCategory);
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchTerm]);

  const bestSellers = useMemo(() => MASTER_PRODUCTS.filter(p => p.isEssential), []);
  const categories = ['All', 'Vegetables', 'Fruits', 'Packaged'];

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === id);
      if (existing && existing.quantity > 1) return prev.map(item => item.id === id ? { ...item, quantity: item.quantity - 1 } : item);
      return prev.filter(item => item.id !== id);
    });
  };

  const totalAmount = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.quantity), 0), [cart]);

  const handleWhatsAppOrder = () => {
    const itemsText = cart.map(item => `- ${item.name}: ${item.quantity} ${item.unit} (₹${item.price * item.quantity})`).join('%0A');
    const message = `*GREEN TRUST ORDER*%0A%0A*Delivery To:* ${location}%0A%0A*Items:*%0A${itemsText}%0A%0A*Grand Total: ₹${totalAmount}*%0A%0APlease confirm!`;
    window.open(`https://wa.me/919500245626?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Location Header - Updated with bold screenshot styling */}
      <header className="sticky top-0 z-[60] bg-white border-b border-slate-100 px-5 py-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-emerald-600 rounded-2xl flex items-center justify-center text-white text-sm shadow-lg shadow-emerald-100">
              <i className="fas fa-location-arrow"></i>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black text-slate-900 tracking-tight leading-none">{location}</span>
                <i className="fas fa-chevron-down text-[10px] text-emerald-600"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Chennai, Tamil Nadu</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="bg-emerald-50 text-emerald-700 text-[10px] font-black px-3 py-1.5 rounded-xl uppercase tracking-wider">Veg</div>
             <button className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-emerald-600 transition"><i className="far fa-user-circle text-2xl"></i></button>
          </div>
        </div>
        
        {/* Search Bar - High Contrast Styling */}
        <div className="relative">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-base"></i>
          <input 
            type="text" 
            placeholder="Search for 'Apple', 'Tomato'..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-100 border-none rounded-2xl py-4 pl-12 pr-4 text-sm font-medium placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500/20 transition-all shadow-inner"
          />
          <i className="fas fa-microphone absolute right-4 top-1/2 -translate-y-1/2 text-rose-500 text-lg"></i>
        </div>
      </header>

      <main className="flex-1 pb-32">
        {activeTab === 'home' && (
          <div className="space-y-8">
            {/* Promo Banner Slider - Bold Titles */}
            <div className="px-5 mt-6 overflow-x-auto scrollbar-hide flex gap-4 snap-x snap-mandatory">
              {[1, 2].map(i => (
                <div key={i} className="flex-shrink-0 w-[88vw] md:w-[60vw] h-48 bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 rounded-[2.5rem] p-8 relative overflow-hidden snap-center shadow-xl shadow-purple-100/20">
                   <div className="relative z-10 text-white h-full flex flex-col justify-center">
                      <p className="text-[11px] font-black uppercase tracking-[0.2em] mb-2 text-purple-300">New Deal Every Hour</p>
                      <h3 className="text-3xl font-black mb-2 leading-tight tracking-tighter">DEAL RUSH</h3>
                      <div className="flex items-center gap-3">
                        <span className="bg-white/20 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-xl border border-white/20 uppercase">Flat ₹125 OFF</span>
                      </div>
                      <button className="mt-6 w-fit bg-white text-indigo-950 px-6 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-white/20 active:scale-95 transition-transform">Order Now</button>
                   </div>
                   <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl"></div>
                   <div className="absolute top-0 right-0 p-8 h-full opacity-30 flex items-center">
                      <i className="fas fa-bolt text-[120px] text-white rotate-12"></i>
                   </div>
                </div>
              ))}
            </div>

            {/* Quick Filters (from screenshot: Min Rs 100 Off etc) */}
            <div className="px-5 flex gap-3 overflow-x-auto scrollbar-hide">
              <button className="flex-shrink-0 bg-white border border-slate-200 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-800 shadow-sm">Min Rs. 100 OFF</button>
              <button className="flex-shrink-0 bg-white border border-slate-200 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-800 shadow-sm">Fast Delivery</button>
              <button className="flex-shrink-0 bg-white border border-slate-200 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-800 shadow-sm">Top Rated</button>
            </div>

            {/* Category Grid - Modern Circles */}
            <div className="px-5">
              <h2 className="text-sm font-black text-slate-900 uppercase tracking-[0.15em] mb-5">Explore Freshness</h2>
              <div className="flex gap-6 overflow-x-auto scrollbar-hide">
                {categories.map((cat, idx) => (
                  <button 
                    key={cat} 
                    onClick={() => setActiveCategory(cat)}
                    className="flex-shrink-0 flex flex-col items-center gap-3 group"
                  >
                    <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center transition-all duration-300 ${activeCategory === cat ? 'bg-emerald-600 shadow-2xl shadow-emerald-200 text-white scale-110' : 'bg-white border border-slate-100 text-slate-400 hover:text-emerald-500 hover:border-emerald-100 shadow-sm'}`}>
                       <i className={`fas ${['fa-house', 'fa-carrot', 'fa-lemon', 'fa-cubes'][idx]} text-2xl`}></i>
                    </div>
                    <span className={`text-[10px] font-black uppercase tracking-wider ${activeCategory === cat ? 'text-emerald-700' : 'text-slate-400 group-hover:text-slate-600'}`}>{cat}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Bestsellers Section (Horizontal Scroll like screenshot) */}
            {activeCategory === 'All' && !searchTerm && (
              <div className="px-5">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-sm font-black text-slate-900 uppercase tracking-[0.15em]">Daily Essentials</h2>
                  <button className="text-[10px] font-black text-emerald-600 uppercase tracking-widest border-b-2 border-emerald-600">See All</button>
                </div>
                <div className="flex overflow-x-auto scrollbar-hide snap-x">
                  {bestSellers.map(p => (
                    <ProductCard key={p.id} product={p} cartQuantity={cart.find(i => i.id === p.id)?.quantity || 0} onAddToCart={addToCart} onRemoveFromCart={removeFromCart} horizontal />
                  ))}
                </div>
              </div>
            )}

            {/* Main Product Grid - Refined Spacing */}
            <div className="px-5">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-[0.15em]">{activeCategory} Collection</h2>
                <span className="bg-slate-200 text-slate-600 text-[9px] font-black px-2 py-1 rounded-md uppercase tracking-tighter">{filteredProducts.length} items</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {filteredProducts.map(p => (
                  <ProductCard key={p.id} product={p} cartQuantity={cart.find(i => i.id === p.id)?.quantity || 0} onAddToCart={addToCart} onRemoveFromCart={removeFromCart} />
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'assistant' && (
          <div className="px-5 mt-8">
            <Assistant cartItems={cart} />
          </div>
        )}
      </main>

      {/* Cart Drawer - Matching the Bold Aesthetic */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/70 backdrop-blur-md flex justify-end">
          <div className="absolute inset-0" onClick={() => setIsCartOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-500 ease-out">
            <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-white">
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter">My Basket <span className="text-emerald-600">({cart.length})</span></h2>
              <button onClick={() => setIsCartOpen(false)} className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors"><i className="fas fa-times text-lg"></i></button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              {cart.map(item => (
                <div key={item.id} className="flex gap-5 items-center bg-slate-50/50 p-4 rounded-[2rem] border border-slate-100">
                  <img src={item.image} className="w-20 h-20 rounded-[1.5rem] object-cover bg-white shadow-sm" />
                  <div className="flex-1">
                    <h4 className="font-extrabold text-slate-900 text-base leading-tight mb-1">{item.name}</h4>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">₹{item.price} x {item.quantity}</p>
                  </div>
                  <div className="flex items-center gap-3 bg-white shadow-sm border border-slate-100 rounded-2xl p-1.5">
                    <button onClick={() => removeFromCart(item.id)} className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-rose-500"><i className="fas fa-minus text-[10px]"></i></button>
                    <span className="text-sm font-black text-slate-900 min-w-[20px] text-center">{item.quantity}</span>
                    <button onClick={() => addToCart(item)} className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-emerald-600"><i className="fas fa-plus text-[10px]"></i></button>
                  </div>
                </div>
              ))}
              {cart.length === 0 && (
                 <div className="h-full flex flex-col items-center justify-center text-center py-20 opacity-40">
                    <i className="fas fa-shopping-basket text-7xl mb-6 text-slate-200"></i>
                    <p className="text-xl font-black text-slate-900 mb-2">Basket is Empty</p>
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Fresh stuff is waiting!</p>
                 </div>
              )}
            </div>
            <div className="p-8 border-t border-slate-50 bg-white">
              <div className="flex justify-between items-end mb-8">
                <div className="flex flex-col">
                  <span className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">To Pay</span>
                  <span className="text-4xl font-black text-slate-900 tracking-tighter">₹{totalAmount}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1.5 rounded-xl">Free Delivery</span>
                </div>
              </div>
              <button onClick={handleWhatsAppOrder} className="w-full bg-emerald-600 text-white py-5 rounded-3xl font-black text-sm uppercase tracking-[0.2em] flex items-center justify-center gap-4 shadow-2xl shadow-emerald-200 active:scale-95 transition-all">
                <i className="fab fa-whatsapp text-2xl"></i> Complete Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Floating Basket Notification */}
      {cart.length > 0 && !isCartOpen && (activeTab === 'home') && (
        <div className="fixed bottom-24 inset-x-5 z-50 bg-slate-900 text-white p-5 rounded-[2.5rem] flex items-center justify-between shadow-2xl animate-in slide-in-from-bottom duration-500 ease-out">
           <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-900/20">
                 <i className="fas fa-basket-shopping text-xl"></i>
              </div>
              <div className="flex flex-col">
                 <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 leading-none mb-1.5">{cart.length} items added</p>
                 <p className="text-xl font-black leading-none tracking-tight">₹{totalAmount}</p>
              </div>
           </div>
           <button onClick={() => setIsCartOpen(true)} className="flex items-center gap-3 font-black uppercase text-[11px] tracking-[0.2em] text-emerald-400 hover:translate-x-1 transition-transform bg-white/5 py-3 px-6 rounded-2xl border border-white/10">
              View <i className="fas fa-arrow-right"></i>
           </button>
        </div>
      )}

      {/* Bottom Navigation Bar - Updated Weights */}
      <nav className="fixed bottom-0 inset-x-0 z-[70] bg-white border-t border-slate-100 h-20 safe-bottom flex items-center justify-around px-4 shadow-[0_-10px_40px_rgba(0,0,0,0.04)]">
        {[
          { id: 'home', icon: 'fa-house', label: 'Home' },
          { id: 'categories', icon: 'fa-magnifying-glass', label: 'Explore' },
          { id: 'assistant', icon: 'fa-wand-magic-sparkles', label: 'Smart AI' },
          { id: 'account', icon: 'fa-circle-user', label: 'Account' }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-2 min-w-[70px] transition-all duration-300 ${activeTab === tab.id ? 'text-emerald-600 -translate-y-1' : 'text-slate-300 hover:text-slate-400'}`}
          >
            <i className={`fa-solid ${tab.icon} text-xl`}></i>
            <span className="text-[9px] font-black uppercase tracking-widest">{tab.label}</span>
            {activeTab === tab.id && <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-pulse"></div>}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
