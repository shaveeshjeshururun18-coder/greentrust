
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  cartQuantity: number;
  onRemoveFromCart: (id: string) => void;
  horizontal?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onAddToCart, 
  cartQuantity,
  onRemoveFromCart,
  horizontal = false
}) => {
  if (horizontal) {
    return (
      <div className="flex-shrink-0 w-44 bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm mr-4">
        <div className="relative h-32 bg-slate-50">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <div className="p-3">
          <h4 className="text-xs font-bold text-slate-800 truncate mb-1 leading-tight">{product.name}</h4>
          <p className="text-sm font-extrabold text-emerald-600 mb-2 leading-none">₹{product.price} <span className="text-[9px] text-slate-400 font-medium uppercase">/ {product.unit}</span></p>
          {cartQuantity === 0 ? (
            <button onClick={() => onAddToCart(product)} className="w-full py-2 bg-white border-2 border-emerald-600 text-emerald-600 rounded-xl text-[10px] font-black hover:bg-emerald-50 transition-colors uppercase tracking-widest">Add</button>
          ) : (
            <div className="flex items-center justify-between bg-emerald-600 text-white rounded-xl px-2 py-1.5 text-xs font-black shadow-lg shadow-emerald-100">
              <button onClick={() => onRemoveFromCart(product.id)} className="w-8 flex justify-center"><i className="fas fa-minus text-[10px]"></i></button>
              <span className="text-sm">{cartQuantity}</span>
              <button onClick={() => onAddToCart(product)} className="w-8 flex justify-center"><i className="fas fa-plus text-[10px]"></i></button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm flex flex-col h-full hover:shadow-md transition-shadow duration-300">
      <div className="relative aspect-square bg-slate-50">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        {product.isEssential && (
          <span className="absolute top-2 left-2 bg-rose-500 text-white text-[8px] font-black px-2 py-1 rounded-lg uppercase tracking-wider shadow-sm">Popular</span>
        )}
      </div>
      <div className="p-3.5 flex flex-col flex-1">
        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-[0.1em] mb-1.5 truncate">{product.category}</p>
        <h3 className="text-sm font-bold text-slate-900 leading-[1.3] mb-3 flex-1 line-clamp-2">{product.name}</h3>
        <div className="flex items-center justify-between mt-auto">
          <div className="flex flex-col">
            <span className="text-base font-black text-slate-900 tracking-tight">₹{product.price}</span>
            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">/{product.unit}</span>
          </div>
          <div className="w-20">
            {cartQuantity === 0 ? (
              <button onClick={() => onAddToCart(product)} className="w-full py-2.5 bg-emerald-50 border-2 border-emerald-100 text-emerald-600 rounded-xl text-[10px] font-black hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all uppercase tracking-widest">Add</button>
            ) : (
              <div className="flex items-center justify-between bg-emerald-600 text-white rounded-xl py-2 px-2 text-xs font-black shadow-lg shadow-emerald-100">
                <button onClick={() => onRemoveFromCart(product.id)} className="w-5 h-5 flex items-center justify-center"><i className="fas fa-minus text-[8px]"></i></button>
                <span className="text-sm">{cartQuantity}</span>
                <button onClick={() => onAddToCart(product)} className="w-5 h-5 flex items-center justify-center"><i className="fas fa-plus text-[8px]"></i></button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
